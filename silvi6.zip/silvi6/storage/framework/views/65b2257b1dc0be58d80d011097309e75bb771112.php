

<?php $__env->startSection('content'); ?>
    <a href="<?php echo e(url('/product/add')); ?>">
        <button class="btn btn-primary mt-4" type="button">+ Tambah Produk</button>
    </a>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card mt-3">
            <div class="card-body">
                <div class="card-title">
                    <?php echo e($item->name); ?> ( <?php echo e($item->price); ?> )
                </div>
                <h6 class="card-subtitle mb-2 text-muted"><?php echo e($item->category->name); ?></h6>
                <div class="card-text"><?php echo e($item->description); ?></div>
                <a href="/product/<?php echo e($item->id); ?>/edit">
                    <button class="btn btn-warning mt-2" type="button">Ubah</button>
                </a>
                <a href="/product/<?php echo e($item->id); ?>/delete">
                    <button class="btn btn-danger mt-2" type="button">Hapus</button>
                </a>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\silvi6\resources\views/product/index.blade.php ENDPATH**/ ?>